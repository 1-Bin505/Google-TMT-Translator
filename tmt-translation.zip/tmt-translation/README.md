# TMT Translation - Chrome Extension

A lightweight browser extension for real-time translation between Nepali, English, and Tamang directly from your toolbar — with a built-in Reading Mode for translating selected text or entire webpages in place.

## Overview

TMT Translation is a Chrome/Edge extension that lets users translate text without leaving their current tab. It integrates with the TMT Translation API to provide fast, accurate multilingual translation across three languages.

**Supported Languages:**
- English
- Nepali (नेपाली)
- Tamang (तामाङ)

---

## Features

### Popup Translation
- Clean toolbar popup with source and target language selectors
- Type or paste any text and translate instantly
- Copy result to clipboard with one click
- Character counter (up to 2000 characters)
- Clear button to reset input and output

### Selection Translation (Auto)
- Select text on any webpage and click the extension icon
- Popup opens with the selected text pre-filled and automatically translated
- No copy-paste needed

### Right-Click Translation
- Select text on any webpage
- Right-click → **"Translate with TMT"**
- Translation appears as a toast notification on the page

### 📖 Reading Mode
- Toggle Reading Mode using the book icon (📖) in the popup header
- The normal input/output UI is replaced with two focused action buttons
- **Translate Selection** — reads the text currently highlighted on the page, translates it, and shows the result inside the popup with a Copy button
- **Translate Page** — walks the entire visible page content, skips navigation/footer/scripts/code, translates every text sentence in place, and reports how many sentences were replaced
- Target language selector stays accessible in Reading Mode
- Reading Mode preference is remembered across sessions

### Language Controls
- Swap source and target languages with one click
- Language preference is remembered across sessions
- Prevents selecting the same language on both sides

### Settings
- Secure API key management via the built-in Settings panel
- Key is stored locally in the browser — never hardcoded
- Show/hide key toggle for safe entry

---

## System Architecture

```
┌──────────────────────────────┐
│        User Browser          │
│   (Chrome Extension Popup)   │
│   - Normal translation UI    │
│   - Reading Mode UI          │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│     Content Script Layer     │
│  - Reads selected page text  │
│  - Shows toast notifications │
│  - DOM walker for page trans │
│  - In-place text replacement │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│    Background Script Layer   │
│  - Handles API calls         │
│  - Context menu integration  │
│  - Message relay (CORS safe) │
│  - Completion reporting      │
└──────────────┬───────────────┘
               │
               ▼
┌──────────────────────────────┐
│        TMT API               │
│  Translation (sentence-level)│
└──────────────────────────────┘
```

---

## API Integration

### TMT Translation API
- Used for all translation between English, Nepali, and Tamang
- Works at sentence-level granularity — text is split sentence by sentence, translated sequentially, then reassembled
- A 150ms delay is applied between sentences to respect server rate limits
- All API calls are routed through the background service worker to avoid CORS issues and protect the API key

---

## Key Technical Details

### Sentence-Level Translation Constraint
The TMT API translates one sentence at a time.

**Solution:**
- Text is split on `.` `!` `?` `।` (Devanagari danda) and newlines
- Each sentence is translated sequentially with a 150ms inter-sentence delay
- Results are rejoined and displayed as a single output

### Reading Mode — DOM Walking
The page translation feature uses a `TreeWalker` to safely traverse the DOM.

**Skipped elements:** `<script>`, `<style>`, `<nav>`, `<footer>`, `<header>`, `<aside>`, `<code>`, `<pre>`, `<input>`, `<textarea>`, `<button>`, `<svg>`, `<canvas>`, and more — ensuring only meaningful readable content is translated.

**In-place replacement:** Original text nodes are updated directly, preserving the page layout and structure. Leading and trailing whitespace of each node is preserved.

**Error resilience:** If a single sentence fails to translate, the original text is kept for that sentence and the rest of the page continues translating. On API key/auth errors, the entire run stops immediately with a clear message.

### In-Memory Caching
Repeated translations of the same text and language pair return instantly from cache without making a new API call.

### API Key Security
- The API key is never hardcoded in source files
- Stored using `chrome.storage.sync` — encrypted by Chrome, never exposed in the codebase
- Removed from storage entirely (not set to empty string) when cleared, preventing stale state bugs

### Network Error Recovery
- If the browser goes offline, a clear error message is shown in both normal and Reading Mode
- When the browser comes back online, the error is automatically cleared in both modes so the user can try again

---

## Limitations
- Depends on TMT API availability
- Sentence-level processing introduces slight latency on longer texts and full-page translations
- Page translation on very long articles may take time due to per-sentence API calls
- Dynamic websites that update their DOM after load may overwrite translated content
- Requires a stable internet connection
- Maximum 2000 characters per translation request in normal mode

---

## Future Improvements
- Parallel sentence translation for faster page translation
- MutationObserver to handle dynamically loaded page content
- Offline fallback mode
- Extended language support
- Translation history log
- Auto language detection
- Restore original page text after page translation

---

## 📁 Project Structure

```
tmt-translation/
├── manifest.json                  # Chrome extension config (Manifest V3)
├── icons/                         # Extension icons
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── src/
    ├── shared/
    │   ├── languages.js           # Language code definitions and normalization
    │   └── api.js                 # TMT API client — caching, storage, error handling
    ├── background/
    │   └── background.js          # Service worker — context menu, API relay
    ├── content/
    │   └── content.js             # Toast notifications + Reading Mode page translation
    └── popup/
        ├── popup.html             # Popup UI — normal mode + Reading Mode panels
        ├── popup.css              # Styles — light/dark mode + Reading Mode styles
        └── popup.js               # All popup logic — normal mode + Reading Mode
```

---

## 🚀 Installation

### Option 1 — Download ZIP (Recommended)

**[⬇ Download tmt-translation-extension.zip](../../releases/latest/download/tmt-translation-extension.zip)**

1. Download and unzip the file
2. Open Chrome and go to `chrome://extensions`
3. Enable **Developer Mode** (toggle in the top-right corner)
4. Click **Load unpacked**
5. Select the `tmt-translation/` folder — the one containing `manifest.json`
6. The **TMT Translation** icon appears in your toolbar

> 📌 Pin the extension by clicking the puzzle piece icon → pin TMT Translation.

### Option 2 — Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/tmt-translation.git
```

Then follow steps 2–6 above, selecting the cloned folder.

---

## 🔑 Adding Your API Key

1. Click the **TMT Translation** icon in the toolbar
2. Click the **⚙** Settings icon in the top-right
3. Paste your API key into the **"API Key"** field
4. Click **Save Key**
5. You will see a **✓ Saved** confirmation

Your key is stored locally and only used to authenticate requests to the TMT API.

---

## 🌐 How to Use

### Translate Text in the Popup

1. Click the **TMT Translation** toolbar icon
2. Select source and target languages from the dropdowns
3. Type or paste text in the input box
4. Click **Translate**
5. The translation appears in the output box below
6. Click **Copy** to copy the result to your clipboard

### Translate Selected Page Text (Auto)

1. Select any text on a webpage with your mouse
2. Click the **TMT Translation** toolbar icon
3. The popup opens with the selected text pre-filled and translation starts automatically

### Translate Selected Page Text (Right-Click)

1. Select any text on a webpage
2. Right-click → choose **"Translate with TMT"**
3. A notification appears on the page with the translation

### Reading Mode — Translate Selection

1. Click the **TMT Translation** toolbar icon
2. Click the **📖** (book) icon in the header to enter Reading Mode
3. Choose your target language from the **"Translate to"** dropdown
4. Highlight any text on the page
5. Click **Translate Selection**
6. The translation appears in the popup — click **Copy** to copy it

### Reading Mode — Translate Page

1. Click the **TMT Translation** toolbar icon
2. Click the **📖** (book) icon in the header to enter Reading Mode
3. Choose your target language from the **"Translate to"** dropdown
4. Click **Translate Page**
5. All visible text on the page is replaced with the translation in real time
6. The popup shows a confirmation with the number of sentences translated

---

## 🌍 Supported Languages

| Language | Native Name | API Code |
|----------|-------------|----------|
| English  | English     | `en`     |
| Nepali   | नेपाली      | `ne`     |
| Tamang   | तामाङ       | `tmg`    |

Source and target languages must always be different.

---

## 🔒 Security and Privacy

- API key is stored in `chrome.storage.sync` — encrypted by Chrome, never exposed in source code
- The extension only communicates with `tmt.ilprl.ku.edu.np`
- No analytics, no tracking, no third-party services
- All source code is open and auditable in this repository

---

## 🐛 Troubleshooting

| Problem | Fix |
|---------|-----|
| Blue banner says "API key not set" | Go to ⚙ Settings → paste your key → Save Key |
| "Invalid API key" error | Check your key has no extra spaces at the start or end |
| "Network error" message | Check your internet connection — the message clears automatically when you reconnect |
| "Source and target must be different" | Change one of the language dropdowns |
| Extension not appearing after loading | Make sure you selected the folder containing `manifest.json`, not the ZIP itself |
| Right-click menu not showing | Go to `chrome://extensions` → find TMT Translation → click the refresh ↺ icon |
| "No text selected" in Reading Mode | Highlight text on the page before clicking Translate Selection |
| "Could not reach the page" in Reading Mode | Reload the tab and try again — some browser-internal pages cannot be accessed |
| Page translation takes a long time | This is expected for long articles — each sentence is translated individually per API requirements |
| Translated page content reverted | The page's JavaScript may have re-rendered the DOM — try again or use Translate Selection instead |

---

## 📋 API Reference

**Endpoint:** `POST https://tmt.ilprl.ku.edu.np/lang-translate`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <your-api-key>
```

**Request body:**
```json
{
  "text": "Hello, how are you?",
  "src_lang": "en",
  "tgt_lang": "ne"
}
```

**Success response:**
```json
{
  "message_type": "SUCCESS",
  "message": "Translation successful",
  "src_lang": "English",
  "input": "Hello, how are you?",
  "target_lang": "Nepali",
  "output": "नमस्ते, तपाईं कस्तो हुनुहुन्छ?",
  "timestamp": "2026-04-25T10:32:00Z"
}
```

**Error response:**
```json
{
  "message": "Invalid API token"
}
```

> Translated text is always in the `output` field.
> Error responses do not include `message_type` — only a `message` string.

---

## 🏁 Built for Google TMT Hackathon 2026 — Track 1
